import { Taskmodel } from './taskmodel.model';

describe('Taskmodel', () => {
  it('should create an instance', () => {
    expect(new Taskmodel()).toBeTruthy();
  });
});
