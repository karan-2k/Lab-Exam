export class Taskmodel {
    exname:String;
    duration:String;
    date:String;
}
