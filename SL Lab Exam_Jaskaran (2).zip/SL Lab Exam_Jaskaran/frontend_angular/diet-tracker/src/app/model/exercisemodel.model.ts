export class Exercisemodel {
    date:Number;
    calorie:String;
    weight:String;
    height:String;
}
