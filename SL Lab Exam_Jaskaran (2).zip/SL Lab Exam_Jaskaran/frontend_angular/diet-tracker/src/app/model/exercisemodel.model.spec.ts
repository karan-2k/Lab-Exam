import { Exercisemodel } from './exercisemodel.model';

describe('Exercisemodel', () => {
  it('should create an instance', () => {
    expect(new Exercisemodel()).toBeTruthy();
  });
});
