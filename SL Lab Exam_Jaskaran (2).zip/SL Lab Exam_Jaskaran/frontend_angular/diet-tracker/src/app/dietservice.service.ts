import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Exercisemodel } from './model/exercisemodel.model';
import { Taskmodel } from './model/taskmodel.model'; //Should have been diet here

@Injectable({
  providedIn: 'root'
})
export class DietserviceService {

  readonly exURL='http://localhost:3000/exercises';
  readonly dietURL='http://localhost:3000/diets';
  constructor(private http:HttpClient) { }

  insertExercise(e:Taskmodel)
  {
    return this.http.post(this.exURL,e);
  }

  insertDiet(t:Exercisemodel)
  {
    return this.http.post(this.dietURL,t);

  }
  getExercise()
  {
    return this.http.get(this.exURL);
  }

  getDiet()
  {
    return this.http.get(this.dietURL);
  }
}
