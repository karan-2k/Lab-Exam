import { Component, OnInit } from '@angular/core';
import { DietserviceService } from 'src/app/dietservice.service';
import { NgForm } from '@angular/forms';
import { Taskmodel } from 'src/app/model/taskmodel.model';

@Component({
  selector: 'app-add-exercise',
  templateUrl: './add-exercise.component.html',
  styleUrls: ['./add-exercise.component.css']
})
export class AddExerciseComponent implements OnInit {

  constructor(public manageService: DietserviceService) { }

  readonly oneex: Taskmodel={exname:'',duration:'',date:''};
  ngOnInit(): void {
  }

  addTasks(form:NgForm)
  {
    this.oneex.duration=form.value.duration;
    this.oneex.exname=form.value.exname;
    this.oneex.date=form.value.date;
    console.log(this.oneex);
    this.manageService.insertExercise(this.oneex).subscribe((res)=>{
      console.log(res);
    })
  }
}
