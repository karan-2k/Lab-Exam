import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DietserviceService } from 'src/app/dietservice.service';
import { Exercisemodel } from 'src/app/model/exercisemodel.model';
import { Taskmodel } from 'src/app/model/taskmodel.model';

@Component({
  selector: 'app-add-diet',
  templateUrl: './add-diet.component.html',
  styleUrls: ['./add-diet.component.css']
})
export class AddDietComponent implements OnInit {

  readonly onediet: Exercisemodel={date:null,calorie:'',weight:'',height:''};
  constructor(public manageService: DietserviceService) { }

  ngOnInit(): void {
  }


  addDiet(form:NgForm)
  {
    this.onediet.calorie=form.value.calorie;
    this.onediet.date=form.value.date;
    this.onediet.height=form.value.height;
    this.onediet.weight=form.value.weight;
    console.log(this.onediet);
    this.manageService.insertDiet(this.onediet).subscribe((res)=>{
      console.log(res);
    })
  }
}
