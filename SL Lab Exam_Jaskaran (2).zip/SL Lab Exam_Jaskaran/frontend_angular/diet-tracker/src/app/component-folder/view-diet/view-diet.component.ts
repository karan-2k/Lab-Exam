import { Component, OnInit } from '@angular/core';
import { DietserviceService } from 'src/app/dietservice.service';
import { Exercisemodel } from 'src/app/model/exercisemodel.model';

@Component({
  selector: 'app-view-diet',
  templateUrl: './view-diet.component.html',
  styleUrls: ['./view-diet.component.css']
})
export class ViewDietComponent implements OnInit {

  diets:Exercisemodel[];
  constructor(public manageService:DietserviceService) { }

  ngOnInit(): void {
    setInterval(()=>{
      this.refreshDietsList()
    },1000);
  }

  refreshDietsList(){
    return this.manageService.getDiet().subscribe((res)=>{
      this.diets = res as Exercisemodel[];
      console.log(this.diets);
    })
  }

}
