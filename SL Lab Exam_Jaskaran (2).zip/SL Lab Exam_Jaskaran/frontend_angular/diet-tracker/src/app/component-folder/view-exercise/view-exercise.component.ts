import { Component, OnInit } from '@angular/core';
import { DietserviceService } from 'src/app/dietservice.service';
import { Taskmodel } from 'src/app/model/taskmodel.model';

@Component({
  selector: 'app-view-exercise',
  templateUrl: './view-exercise.component.html',
  styleUrls: ['./view-exercise.component.css']
})
export class ViewExerciseComponent implements OnInit {

  exercises:Taskmodel[];
  constructor(public manageService:DietserviceService) { }

  ngOnInit(): void {
    setInterval(()=>{
      this.refreshExerciseList()
    },1000);
  }

  refreshExerciseList(){
    return this.manageService.getExercise().subscribe((res)=>{
      this.exercises = res as Taskmodel[];
      console.log(this.exercises);
    })
  }
}
