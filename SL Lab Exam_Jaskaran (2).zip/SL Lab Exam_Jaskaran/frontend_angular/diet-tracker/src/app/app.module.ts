import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatToolbarModule} from '@angular/material/toolbar';
import {MatCardModule} from '@angular/material/card';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { HttpClientModule } from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { AddDietComponent } from './component-folder/add-diet/add-diet.component';
import { AddExerciseComponent } from './component-folder/add-exercise/add-exercise.component';
import { ViewExerciseComponent } from './component-folder/view-exercise/view-exercise.component';
import { ViewDietComponent } from './component-folder/view-diet/view-diet.component';
import { DietserviceService } from './dietservice.service';

@NgModule({
  declarations: [
    AppComponent,
    AddDietComponent,
    AddExerciseComponent,
    ViewExerciseComponent,
    ViewDietComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [DietserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
