import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddDietComponent } from './component-folder/add-diet/add-diet.component';
import { AddExerciseComponent } from './component-folder/add-exercise/add-exercise.component';
import { ViewDietComponent } from './component-folder/view-diet/view-diet.component';
import { ViewExerciseComponent } from './component-folder/view-exercise/view-exercise.component';

const routes: Routes = [
  {path:'',component:AddDietComponent},
  {path:'viewdiets',component:ViewDietComponent},
  {path:'viewexercise',component:ViewExerciseComponent},
  {path:'addexercise',component:AddExerciseComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
