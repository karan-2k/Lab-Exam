const express = require('express');

const cors= require('cors');
const app=express();
const mongoose = require('./database/mongoose');


const {Diet}= require('./database/models/diet');
const {Exercise}= require('./database/models/exercise');


//To use the json data 
app.use(express.json());
//To enable the cross origin resource sharing between node and angular
app.use(cors({origin:'http://localhost:4200'}));

app.listen(3000,(err)=>{
    if(!err)
        console.log('Server running on port 3000');
    
    else
        console.log(err);
});

//Get exercise data
app.get('/exercises',(req,res)=>{
    Exercise.find((err,exercise)=>{
        if(!err)
            res.send(exercise);
        else
            console.log(err);
    });
});

//Add exercises
app.post('/exercises',(req,res)=>{
    var detail= new Exercise({
        exname: req.body.exname,
        duration: req.body.duration,
        date:req.body.date
    });
    detail.save((err,details)=>{
        if(!err){
            res.send(details);
            console.log(details);
        }
            
        else
            console.log(err);
    });
});





//See all tasks
app.get('/diets',(req,res)=>{
    Diet.find((err,diet)=>{
        if(!err){
            res.send(diet);
        }
        else
        {
            console.log(err);
        }

    });
});

app.post('/diets',(req,res)=>{
    var detail=new Diet({
        date: req.body.date,
        calorie:req.body.calorie,
        weight:req.body.weight,
        height:req.body.height,
    });

    detail.save((err,details)=>{
        if(!err)
            res.send(details);
        else
            console.log(err);
    });
});



