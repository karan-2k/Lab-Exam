const mongoose = require('mongoose');

//Url to connect to my mongodb atlas database
uri="mongodb+srv://karan:8nqmi865uVzZ6YYy@cluster0.wup9w.mongodb.net/DietTrack?retryWrites=true&w=majority";

//connection
mongoose.connect(uri,{useNewUrlParser:true, useUnifiedTopology:true},(err)=>{
    if(!err)
    {
        console.log('Database connected Successfully');
    }
    else
    {
        console.log(err);
    }
});

module.exports=mongoose;