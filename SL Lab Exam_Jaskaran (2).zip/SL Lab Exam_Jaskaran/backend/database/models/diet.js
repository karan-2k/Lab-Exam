const mongoose = require('mongoose');

const DietSchema = new mongoose.Schema({
    date:{type:String},
    calorie:{type: String, trim:true},
    weight:{type:String,trim:true},
    height:{type:String,trim:true}
});

const Diet = mongoose.model('Diet',DietSchema);

module.exports={Diet};