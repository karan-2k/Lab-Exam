const mongoose = require('mongoose');

const ExerciseSchema= new mongoose.Schema({
    exname:{type:String},
    duration:{type:String},
    date:{type:String}
});

const Exercise = new mongoose.model('Exercise',ExerciseSchema);

module.exports = {Exercise};